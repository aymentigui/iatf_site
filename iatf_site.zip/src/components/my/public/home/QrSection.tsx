"use client";
import React, { useEffect } from "react";
import { useLocale, useTranslations } from "next-intl";
import Image from "next/image";

const QrSection = () => {
    const t = useTranslations("qr"); // traduction section qr
    const locale = useLocale();

    useEffect(()=>{
        console.log("Locale in QrSection:", locale);
    },[])

    return (
        <section className="w-full py-12 bg-gradient-to-r from-blue-50 to-blue-100">
            <div className="container mx-auto px-6 flex flex-col lg:flex-row items-center justify-center gap-10">
                {/* Texte */}
                <div className={"text-center max-w-lg "+(locale === "ar" ? " lg:text-right" : " lg:text-left")}>
                    <h2 className="text-2xl md:text-4xl font-bold text-blue-900 mb-4">
                        {t("title")}
                    </h2>
                    <p className="text-lg text-gray-700 mb-6">{t("description")}</p>
                    <a
                        href="https://bus.iatf-dz.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-blue-700 text-white rounded-xl shadow-lg hover:bg-blue-800 transition"
                    >
                        {t("button")}
                    </a>
                </div>

                {/* QR Code */}
                <div className="flex justify-center items-center">
                    <Image
                        src="/qr_bus_iatf_dz.png" // mets ton image QR code ici dans public/
                        alt="QR Code"
                        width={220}
                        height={220}
                        className="rounded-xl shadow-xl border border-gray-300"
                    />
                </div>
            </div>
        </section>
    );
};

export default QrSection;
