import React from 'react'

const ModalClass = () => {
  return (
    <div className='hidden'>
        <div className='w-[70%] max-w-[70%] h-[80%] '></div>
    </div>
  )
}

export default ModalClass
