import React from 'react'

const FooterFrom = () => {
  return (
    <div className='w-full h-20'>
      
    </div>
  )
}

export default FooterFrom
