"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Bus, Calendar, Clock, MapPin, User } from "lucide-react"
import { z } from "zod"
import toast from "react-hot-toast"

const busRequestSchema = z.object({
    name: z.string().min(2, "Le nom doit contenir au moins 2 caractères").optional().or(z.literal("")),
    hotel: z.string().min(2, "L'hôtel doit contenir au moins 2 caractères").optional().or(z.literal("")),
    date: z.string().min(1, "La date est requise"),
    time: z.string().min(1, "L'heure est requise"),
})

type BusRequestFormData = z.infer<typeof busRequestSchema>


export function BusRequestForm() {
    const [isSubmitting, setIsSubmitting] = useState(false)
    const [submitSuccess, setSubmitSuccess] = useState(false)

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
    } = useForm<BusRequestFormData>({
        resolver: zodResolver(busRequestSchema),
    })

    const onSubmit = async (data: BusRequestFormData) => {
        setIsSubmitting(true)
        setSubmitSuccess(false)

        try {
            const response = await fetch("/api/bus-request", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })

            const result = await response.json()

            if (response.ok) {
                setSubmitSuccess(true)
                reset()
                toast("Votre demande de bus a été enregistrée avec succès.",)
            } else {
                toast.error(result.message || "Une erreur est survenue lors de l'envoi.",)
            }
        } catch (error) {
            toast.error( "Impossible de soumettre votre demande. Veuillez réessayer.",)
        } finally {
            setIsSubmitting(false)
        }
    }

    return (
        <Card className="w-full max-w-md mx-auto">
            <CardHeader className="text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <Bus className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-2xl font-bold">Demande de Bus</CardTitle>
                <CardDescription>Remplissez ce formulaire pour réserver votre transport</CardDescription>
            </CardHeader>
            <CardContent>
                {submitSuccess && (
                    <Alert className="mb-6 border-green-200 bg-green-50 text-green-800">
                        <AlertDescription>Votre demande a été enregistrée avec succès !</AlertDescription>
                    </Alert>
                )}

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="name" className="flex items-center gap-2">
                            <User className="h-4 w-4" />
                            Nom (optionnel)
                        </Label>
                        <Input
                            id="name"
                            placeholder="Votre nom complet"
                            {...register("name")}
                            className={errors.name ? "border-destructive" : ""}
                        />
                        {errors.name && <p className="text-sm text-destructive">{errors.name.message}</p>}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="hotel" className="flex items-center gap-2">
                            <MapPin className="h-4 w-4" />
                            Hôtel (optionnel)
                        </Label>
                        <Input
                            id="hotel"
                            placeholder="Nom de l'hôtel"
                            {...register("hotel")}
                            className={errors.hotel ? "border-destructive" : ""}
                        />
                        {errors.hotel && <p className="text-sm text-destructive">{errors.hotel.message}</p>}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="date" className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            Date *
                        </Label>
                        <Input id="date" type="date" {...register("date")} className={errors.date ? "border-destructive" : ""} />
                        {errors.date && <p className="text-sm text-destructive">{errors.date.message}</p>}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="time" className="flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            Heure *
                        </Label>
                        <Input id="time" type="time" {...register("time")} className={errors.time ? "border-destructive" : ""} />
                        {errors.time && <p className="text-sm text-destructive">{errors.time.message}</p>}
                    </div>

                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                        {isSubmitting ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Envoi en cours...
                            </>
                        ) : (
                            "Soumettre la demande"
                        )}
                    </Button>
                </form>
            </CardContent>
        </Card>
    )
}
