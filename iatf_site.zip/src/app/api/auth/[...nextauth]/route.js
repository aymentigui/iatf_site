import {handler} from "next-auth"

export { handler as GET, handler as POST }