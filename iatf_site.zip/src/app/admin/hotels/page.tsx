import { List } from "./_components/list";

export default async function ItemsPage() {
  return <List />
}
